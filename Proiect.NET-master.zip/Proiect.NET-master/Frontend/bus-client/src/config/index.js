const config = {
    serverURL: 'http://localhost:49536/api/v1',
    googleApiKey: 'AIzaSyCFIiFXUc2AM1SaUU8cbsShdoY1NAiH8_s',
    };

export default config;