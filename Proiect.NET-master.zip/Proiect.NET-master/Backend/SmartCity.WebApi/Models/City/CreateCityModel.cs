﻿namespace SmartCity.WebApi.Models.City
{
    public class CreateCityModel
    {
        public string Name { get; set; }
    }
}
