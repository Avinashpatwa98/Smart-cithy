﻿namespace SmartCity.WebApi.Models.Coordinates
{
    public class CoordinatesModel
    {
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
