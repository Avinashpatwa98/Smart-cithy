﻿using SmartCity.WebApi.Models.Coordinates;

namespace SmartCity.WebApi.Models.Bus
{
    public class CreateBusModel
    {
        public CoordinatesModel Coordinates { get; set; }
    }
}
